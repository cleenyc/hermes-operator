"""Hermes native bridge for the autonomous operator control plane."""

from __future__ import annotations

import atexit
from datetime import datetime, timezone
from functools import lru_cache
import json
import logging
from pathlib import Path
from threading import Lock
from typing import Any

from .client import OperatorClient
from .config import ConfigurationError, PluginConfig
from .hooks import LifecycleEmitter, PolicyAttestationRefresher, build_hooks
from .policy import (
    POLICY_DIGEST,
    POLICY_MODE,
    POLICY_VERSION,
    TaskScopedPolicyGuard,
    guard_external_side_effects,
)
from . import schemas, tools

logger = logging.getLogger(__name__)

PLUGIN_VERSION = "1.2.0"

_active_refresher: PolicyAttestationRefresher | None = None
_active_refresher_lock = Lock()


@lru_cache(maxsize=1)
def _client() -> OperatorClient:
    return OperatorClient(PluginConfig.from_env())


@lru_cache(maxsize=1)
def _emitter() -> LifecycleEmitter:
    return LifecycleEmitter(_client())


def _activate_refresher(refresher: PolicyAttestationRefresher) -> None:
    """Keep exactly one heartbeat alive for this loaded plugin module."""

    global _active_refresher
    with _active_refresher_lock:
        previous = _active_refresher
        if previous is refresher:
            return
        if previous is not None:
            previous.stop()
        _active_refresher = None
        refresher.start()
        _active_refresher = refresher


def _stop_active_refresher() -> None:
    global _active_refresher
    with _active_refresher_lock:
        refresher = _active_refresher
        _active_refresher = None
    if refresher is not None:
        refresher.stop()


atexit.register(_stop_active_refresher)


def _command(raw_args: str) -> str:
    """Implement the read-only /operator slash command."""

    command = (raw_args or "").strip().lower()
    if command in {"", "status"}:
        return tools.status(_client(), {})
    if command in {"next", "priorities"}:
        return tools.next_work(_client(), {"limit": 8})
    if command in {"questions", "input"}:
        return tools.open_questions(_client(), {"limit": 20})
    return json.dumps(
        {
            "success": False,
            "error": "Usage: /operator [status|next|questions]",
        }
    )


def _policy_attestation(profile: str) -> dict[str, Any]:
    return {
        "profile": profile,
        "plugin_version": PLUGIN_VERSION,
        "policy_version": POLICY_VERSION,
        "policy_digest": POLICY_DIGEST,
        "guard_active": True,
        "policy_mode": POLICY_MODE,
        "attested_at": datetime.now(timezone.utc).isoformat(),
    }


def register(ctx: Any) -> None:
    """Register against current Hermes APIs and degrade on optional surfaces."""

    register_hook = getattr(ctx, "register_hook", None)
    if not callable(register_hook):
        raise RuntimeError(
            "Hermes Operator requires the documented pre_tool_call policy hook"
        )
    client: OperatorClient | None = None
    try:
        client = _client()
    except ConfigurationError as exc:
        logger.warning(
            "Hermes operator bridge unavailable; pre_tool_call policy remains active: %s",
            exc,
        )
    guard = TaskScopedPolicyGuard(
        client.execution_contract if client is not None else None,
        client.claim_delegation if client is not None else None,
        expected_profile=client.config.profile if client is not None else "",
    )
    # Registration is the first interaction with Hermes. Missing or invalid bridge
    # configuration therefore degrades to a policy-only guard that fails closed for
    # every task-scoped capability.
    register_hook("pre_tool_call", guard)
    if client is None:
        return

    try:
        client.attest_policy(_policy_attestation(client.config.profile))
    except Exception as exc:
        logger.error(
            "Hermes operator policy attestation failed; bridge remains disabled: %s",
            exc,
        )
        return

    attestation_refresher = PolicyAttestationRefresher(
        client,
        lambda: _policy_attestation(client.config.profile),
        client.config.attestation_refresh_seconds,
    )
    try:
        _activate_refresher(attestation_refresher)
    except Exception as exc:
        logger.error(
            "Hermes policy heartbeat failed to start; bridge remains disabled: %s",
            exc,
        )
        return

    ctx.register_tool(
        name="operator_status",
        toolset="hermes_operator",
        schema=schemas.OPERATOR_STATUS,
        handler=lambda args, **kwargs: tools.status(client, args, **kwargs),
        description="Check the internal operator control plane.",
    )
    ctx.register_tool(
        name="operator_next_work",
        toolset="hermes_operator",
        schema=schemas.OPERATOR_NEXT_WORK,
        handler=lambda args, **kwargs: tools.next_work(client, args, **kwargs),
        description="Read next-best work suggestions from the operator.",
    )
    ctx.register_tool(
        name="operator_open_questions",
        toolset="hermes_operator",
        schema=schemas.OPERATOR_OPEN_QUESTIONS,
        handler=lambda args, **kwargs: tools.open_questions(client, args, **kwargs),
        description="Read unresolved operator questions.",
    )

    hooks = build_hooks(client, _emitter(), attestation_refresher)
    _register_optional_hooks(ctx, hooks)

    register_command = getattr(ctx, "register_command", None)
    if callable(register_command):
        try:
            register_command(
                "operator", _command, description="Show operator status, priorities, or questions"
            )
        except Exception as exc:
            logger.warning("Could not register /operator command: %s", exc)

    register_skill = getattr(ctx, "register_skill", None)
    skill_path = Path(__file__).parent / "skills" / "operator-workflow" / "SKILL.md"
    if callable(register_skill) and skill_path.exists():
        try:
            register_skill("operator-workflow", skill_path)
        except Exception as exc:
            logger.warning("Could not register operator workflow skill: %s", exc)


def _register_optional_hooks(ctx: Any, hooks: dict[str, Any]) -> None:
    """Register hooks individually so a version mismatch disables only one feature."""

    register_hook = getattr(ctx, "register_hook", None)
    if not callable(register_hook):
        logger.warning("Hermes version does not expose plugin lifecycle hooks")
        return
    for name, callback in hooks.items():
        try:
            register_hook(name, callback)
        except Exception as exc:
            logger.warning("Hermes rejected optional hook %s: %s", name, exc)
