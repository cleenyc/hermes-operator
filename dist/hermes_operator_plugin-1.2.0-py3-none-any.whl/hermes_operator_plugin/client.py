"""Small standard-library client for the operator control plane."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import re
from typing import Any, Mapping
from urllib import error, parse, request

from .config import PluginConfig


class OperatorUnavailable(RuntimeError):
    """The control plane could not answer a plugin request."""


@dataclass(frozen=True, slots=True)
class Response:
    status: int
    data: Any


class _NoRedirect(request.HTTPRedirectHandler):
    """Keep Bearer credentials on the configured origin."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        del req, fp, code, msg, headers, newurl
        return None


class OperatorClient:
    """Bounded HTTP client that exposes only the plugin's narrow contract."""

    def __init__(self, config: PluginConfig):
        self.config = config

    def health(self) -> Any:
        return self._request("GET", "/health").data

    def next_work(self, limit: int = 5) -> Any:
        safe_limit = max(1, min(int(limit), 20))
        query = parse.urlencode({"limit": safe_limit})
        return self._request("GET", f"/v1/next?{query}").data

    def open_questions(self, limit: int = 10) -> Any:
        safe_limit = max(1, min(int(limit), 50))
        query = parse.urlencode({"status": "pending", "limit": safe_limit})
        return self._request("GET", f"/v1/questions?{query}").data

    def execution_contract(self, task_id: str) -> Mapping[str, Any]:
        """Read and validate the exact live authorization for one Hermes task."""

        if not isinstance(task_id, str) or not re.fullmatch(
            r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", task_id
        ):
            raise ValueError("task_id must be a valid Hermes task identity")
        query = parse.urlencode({"task_id": task_id})
        data = self._request(
            "GET", f"/v1/hermes/execution-contract?{query}"
        ).data
        if not isinstance(data, Mapping):
            raise OperatorUnavailable("operator returned an invalid execution contract")
        if data.get("authorized") is not True or data.get("task_id") != task_id:
            raise OperatorUnavailable("operator did not authorize the current Hermes task")
        expected = {
            "authorized",
            "contract_digest",
            "internal_capabilities",
            "profile",
            "run_id",
            "task_id",
            "work_id",
        }
        if set(data) != expected:
            raise OperatorUnavailable("operator execution contract has an invalid shape")
        for key in ("profile", "run_id", "work_id"):
            value = data.get(key)
            if not isinstance(value, str) or not value or len(value) > 128:
                raise OperatorUnavailable(
                    f"operator execution contract has an invalid {key}"
                )
        digest = data.get("contract_digest")
        if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise OperatorUnavailable(
                "operator execution contract has an invalid contract_digest"
            )
        capabilities = data.get("internal_capabilities")
        known = {
            "delegate_task",
            "local_build",
            "local_read",
            "local_test",
            "local_write",
        }
        if (
            not isinstance(capabilities, list)
            or not capabilities
            or len(capabilities) > len(known)
            or len(set(capabilities)) != len(capabilities)
            or any(not isinstance(value, str) or value not in known for value in capabilities)
        ):
            raise OperatorUnavailable(
                "operator execution contract has invalid internal_capabilities"
            )
        return dict(data)

    def claim_delegation(
        self,
        task_id: str,
        requested_children: int,
    ) -> Mapping[str, Any]:
        """Atomically consume one bounded subagent batch for the live run."""

        if not isinstance(task_id, str) or not re.fullmatch(
            r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", task_id
        ):
            raise ValueError("task_id must be a valid Hermes task identity")
        if (
            not isinstance(requested_children, int)
            or isinstance(requested_children, bool)
            or not 1 <= requested_children <= 3
        ):
            raise ValueError("requested_children must be an integer from 1 through 3")
        data = self._request(
            "POST",
            "/v1/hermes/delegation-claim",
            {
                "task_id": task_id,
                "requested_children": requested_children,
            },
        ).data
        expected = {
            "claimed",
            "contract_digest",
            "reason",
            "requested_children",
            "run_id",
            "task_id",
        }
        if not isinstance(data, Mapping) or set(data) != expected:
            raise OperatorUnavailable("operator returned an invalid delegation claim")
        if (
            not isinstance(data.get("claimed"), bool)
            or data.get("task_id") != task_id
            or data.get("requested_children") != requested_children
            or not isinstance(data.get("run_id"), str)
            or not data["run_id"]
            or not isinstance(data.get("contract_digest"), str)
            or not re.fullmatch(r"[0-9a-f]{64}", data["contract_digest"])
            or not isinstance(data.get("reason"), str)
            or not data["reason"]
            or len(data["reason"]) > 128
        ):
            raise OperatorUnavailable("operator returned an invalid delegation claim")
        return dict(data)

    def emit_lifecycle(
        self,
        event_name: str,
        payload: Mapping[str, Any],
        *,
        identity_parts: tuple[str, ...] = (),
    ) -> Any:
        """Record an internal lifecycle event. This cannot approve or send work."""

        safe_event = "".join(
            character
            for character in event_name.lower()
            if character.isalnum() or character in {"_", "."}
        )
        if not safe_event:
            raise ValueError("event_name must contain a safe character")
        occurred_at = datetime.now(timezone.utc).isoformat()
        canonical_identity = json.dumps(
            [safe_event, *identity_parts], separators=(",", ":"), ensure_ascii=True
        ).encode("utf-8")
        digest = hashlib.sha256(canonical_identity).hexdigest()
        body = {
            "source": "hermes_plugin",
            "event_type": f"hermes.{safe_event}",
            "external_id": f"hermes:{digest}",
            "dedupe_key": f"hermes:{digest}",
            "occurred_at": occurred_at,
            "payload": _json_safe(payload),
            "provenance": {
                "origin": "hermes_plugin",
                "trust": "authenticated_untrusted",
            },
        }
        return self._request("POST", "/v1/events/hermes", body).data

    def attest_policy(self, payload: Mapping[str, Any]) -> Any:
        """Synchronously record the required per-profile worker policy attestation."""

        required = {
            "profile",
            "plugin_version",
            "policy_version",
            "policy_digest",
            "guard_active",
            "policy_mode",
            "attested_at",
        }
        if set(payload) != required:
            raise ValueError("policy attestation payload does not match the fixed contract")
        if payload.get("guard_active") is not True:
            raise ValueError("policy attestation requires an active guard")
        if payload.get("policy_mode") != "default_deny":
            raise ValueError("policy attestation requires default-deny mode")
        for key in required - {"guard_active"}:
            if not isinstance(payload.get(key), str) or not payload[key].strip():
                raise ValueError(f"policy attestation field {key} must be a non-empty string")
        if payload["profile"] != self.config.profile:
            raise ValueError("policy attestation profile does not match bridge configuration")
        if not re.fullmatch(r"[0-9a-f]{64}", payload["policy_digest"]):
            raise ValueError("policy attestation digest must be a lowercase SHA-256 hex value")
        try:
            attested_at = datetime.fromisoformat(payload["attested_at"])
        except ValueError as exc:
            raise ValueError("policy attestation timestamp must be ISO 8601") from exc
        if attested_at.tzinfo is None or attested_at.utcoffset() != timezone.utc.utcoffset(None):
            raise ValueError("policy attestation timestamp must include a UTC offset")

        identity = json.dumps(
            [
                payload["profile"],
                payload["plugin_version"],
                payload["policy_version"],
                payload["policy_digest"],
                payload["attested_at"],
            ],
            separators=(",", ":"),
            ensure_ascii=True,
        ).encode("utf-8")
        event_id = f"hermes-policy:{hashlib.sha256(identity).hexdigest()}"
        body = {
            "source": "hermes_plugin",
            "event_type": "policy.attested",
            "external_id": event_id,
            "dedupe_key": event_id,
            "occurred_at": payload["attested_at"],
            "payload": dict(payload),
            "provenance": {
                "origin": "hermes_plugin",
                "trust": "authenticated_untrusted",
            },
        }
        response = self._request("POST", "/v1/events/hermes", body).data
        if (
            not isinstance(response, Mapping)
            or not isinstance(response.get("event_id"), str)
            or not response["event_id"].strip()
            or not isinstance(response.get("created"), bool)
            or response.get("trust_level") != "authenticated_untrusted"
        ):
            raise OperatorUnavailable(
                "operator did not acknowledge the authenticated policy attestation"
            )
        return response

    def _request(self, method: str, path: str, body: Any = None) -> Response:
        endpoint = path.split("?", 1)[0]
        allowed = {
            ("GET", "/health"),
            ("GET", "/v1/hermes/execution-contract"),
            ("GET", "/v1/next"),
            ("GET", "/v1/questions"),
            ("POST", "/v1/hermes/delegation-claim"),
            ("POST", "/v1/events/hermes"),
        }
        normalized_method = method.upper()
        if (normalized_method, endpoint) not in allowed:
            raise ValueError("plugin request is outside its read and observation contract")
        if "#" in path:
            raise ValueError("fragments are not permitted in API paths")

        encoded = None
        headers = {
            "Accept": "application/json",
            "User-Agent": "hermes-operator-plugin/1.0",
        }
        if body is not None:
            encoded = json.dumps(
                body, separators=(",", ":"), ensure_ascii=False
            ).encode("utf-8")
            headers["Content-Type"] = "application/json"
        if self.config.api_token:
            headers["Authorization"] = f"Bearer {self.config.api_token}"

        req = request.Request(
            f"{self.config.base_url}{path}",
            data=encoded,
            headers=headers,
            method=normalized_method,
        )
        try:
            opener = request.build_opener(_NoRedirect())
            with opener.open(req, timeout=self.config.timeout_seconds) as response:
                raw = response.read(self.config.max_response_bytes + 1)
                if len(raw) > self.config.max_response_bytes:
                    raise OperatorUnavailable("operator response exceeded size limit")
                return Response(response.status, _decode_json(raw))
        except error.HTTPError as exc:
            exc.read(2_048)
            raise OperatorUnavailable(f"operator returned HTTP {exc.code}") from exc
        except (error.URLError, TimeoutError, OSError) as exc:
            raise OperatorUnavailable(f"operator is unavailable: {exc}") from exc


def _decode_json(raw: bytes) -> Any:
    if not raw:
        return {}
    try:
        return json.loads(
            raw.decode("utf-8"),
            object_pairs_hook=_unique_object,
            parse_constant=_reject_json_constant,
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise OperatorUnavailable("operator returned invalid JSON") from exc


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _reject_json_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON number: {value}")


def _json_safe(value: Any, *, depth: int = 0) -> Any:
    """Bound hook payloads and remove objects that cannot cross the API safely."""

    if depth > 5:
        return "[depth limit]"
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return value[:8_000]
    if isinstance(value, Mapping):
        return {
            str(key)[:100]: _json_safe(item, depth=depth + 1)
            for key, item in list(value.items())[:100]
        }
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(item, depth=depth + 1) for item in list(value)[:100]]
    return str(value)[:1_000]
