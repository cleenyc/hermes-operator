"""Tool schemas shown to Hermes models."""

OPERATOR_STATUS = {
    "name": "operator_status",
    "description": (
        "Check whether the autonomous operator control plane is reachable. "
        "This is read-only and cannot approve, send, or publish anything."
    ),
    "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
}

OPERATOR_NEXT_WORK = {
    "name": "operator_next_work",
    "description": (
        "Read the operator's current next-best work suggestions and priority reasons. "
        "This does not start work or change task state."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "limit": {
                "type": "integer",
                "minimum": 1,
                "maximum": 20,
                "description": "Maximum suggestions to return.",
            }
        },
        "additionalProperties": False,
    },
}

OPERATOR_OPEN_QUESTIONS = {
    "name": "operator_open_questions",
    "description": (
        "Read unresolved questions that require the operator's context or decision. "
        "This does not answer questions on the user's behalf."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "limit": {
                "type": "integer",
                "minimum": 1,
                "maximum": 50,
                "description": "Maximum questions to return.",
            }
        },
        "additionalProperties": False,
    },
}

