"""Read-only Hermes tool handlers for the operator service."""

from __future__ import annotations

import json
from typing import Any, Callable

from .client import OperatorClient, OperatorUnavailable


def _result(call: Callable[[], Any]) -> str:
    try:
        return json.dumps({"success": True, "data": call()}, ensure_ascii=False)
    except (OperatorUnavailable, ValueError, TypeError) as exc:
        return json.dumps({"success": False, "error": str(exc)}, ensure_ascii=False)
    except Exception:
        return json.dumps(
            {"success": False, "error": "unexpected operator bridge error"}
        )


def status(client: OperatorClient, args: dict, **kwargs: Any) -> str:
    del args, kwargs
    return _result(client.health)


def next_work(client: OperatorClient, args: dict, **kwargs: Any) -> str:
    del kwargs
    return _result(lambda: client.next_work(args.get("limit", 5)))


def open_questions(client: OperatorClient, args: dict, **kwargs: Any) -> str:
    del kwargs
    return _result(lambda: client.open_questions(args.get("limit", 10)))

