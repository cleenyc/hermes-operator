from __future__ import annotations

import hashlib
import hmac
import json
import re
import socket
import threading
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable, Mapping, Sequence
from urllib.parse import parse_qs, unquote, urlsplit

from .approvals import ApprovalStateError, ExternalActionStager
from .db import NotFound, SQLiteStore, StateConflict
from .inbound import (
    InboundValidationError,
    normalize_external_event,
    normalize_operator_event,
    verify_webhook_signature,
)
from .models import QuestionStatus, WorkItem, WorkRelation, WorkStatus, utc_now


WakeCallback = Callable[[str], None]
HealthProvider = Callable[[], Mapping[str, Any]]
NextProvider = Callable[[int], Sequence[WorkItem | Mapping[str, Any]]]
ExecutionContractProvider = Callable[[str], Mapping[str, Any]]
DelegationClaimProvider = Callable[[str, int], Mapping[str, Any]]
RESERVED_WEBHOOK_SOURCES = frozenset({"operator", "system", "hermes"})


@dataclass(slots=True)
class APIContext:
    store: SQLiteStore
    api_token: str = ""
    bridge_token: str = ""
    webhook_secrets: Mapping[str, str] = field(default_factory=dict)
    max_body_bytes: int = 1_048_576
    wake: WakeCallback | None = None
    health_provider: HealthProvider | None = None
    next_provider: NextProvider | None = None
    execution_contract_provider: ExecutionContractProvider | None = None
    delegation_claim_provider: DelegationClaimProvider | None = None
    action_stager: ExternalActionStager | None = None
    allow_unsigned_webhooks: bool = False

    def __post_init__(self) -> None:
        if self.max_body_bytes < 1:
            raise ValueError("max_body_bytes must be positive")
        if (
            self.api_token
            and self.bridge_token
            and hmac.compare_digest(self.api_token, self.bridge_token)
        ):
            raise ValueError("Operator and Hermes bridge tokens must be distinct")
        reserved = RESERVED_WEBHOOK_SOURCES.intersection(self.webhook_secrets)
        if reserved:
            raise ValueError(
                "Reserved webhook sources cannot have HMAC secrets: "
                + ", ".join(sorted(reserved))
            )


class APIError(Exception):
    def __init__(self, status: HTTPStatus, code: str, message: str):
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message


class OperatorHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class OperatorHTTPServerV6(OperatorHTTPServer):
    address_family = socket.AF_INET6


def create_api_server(host: str, port: int, context: APIContext) -> OperatorHTTPServer:
    """Create, but do not start, a portable operator HTTP server."""

    handler = _handler_for(context)
    server_type = OperatorHTTPServerV6 if ":" in host else OperatorHTTPServer
    return server_type((host, port), handler)


class APIService:
    """Small lifecycle wrapper suitable for the main service or tests."""

    def __init__(self, host: str, port: int, context: APIContext):
        self.host = host
        self.port = port
        self.context = context
        self.server: OperatorHTTPServer | None = None
        self._thread: threading.Thread | None = None
        self._lifecycle_lock = threading.Lock()

    @property
    def address(self) -> tuple[str, int]:
        if self.server is None:
            return self.host, self.port
        host, port = self.server.server_address[:2]
        return str(host), int(port)

    def start(self) -> tuple[str, int]:
        with self._lifecycle_lock:
            if self._thread and self._thread.is_alive():
                return self.address
            if self.server is None:
                self.server = create_api_server(self.host, self.port, self.context)
            server = self.server
            self._thread = threading.Thread(
                target=server.serve_forever,
                name="hermes-operator-api",
                daemon=True,
            )
            self._thread.start()
            return self.address

    def stop(self) -> None:
        with self._lifecycle_lock:
            server = self.server
            thread = self._thread
            if server is None:
                return
            if thread and thread.is_alive():
                server.shutdown()
                thread.join(timeout=5)
            server.server_close()
            self.server = None
            self._thread = None


def _validated_policy_attestation(document: Mapping[str, Any]) -> dict[str, Any]:
    """Validate the fixed Hermes plugin attestation envelope and payload."""

    envelope_keys = {
        "source",
        "event_type",
        "external_id",
        "dedupe_key",
        "occurred_at",
        "payload",
        "provenance",
    }
    if set(document) != envelope_keys:
        raise APIError(
            HTTPStatus.BAD_REQUEST,
            "invalid_policy_attestation",
            "Policy attestation envelope does not match the fixed contract",
        )
    if document.get("source") != "hermes_plugin":
        raise APIError(
            HTTPStatus.BAD_REQUEST,
            "invalid_policy_attestation",
            "Policy attestation source is invalid",
        )
    if document.get("provenance") != {
        "origin": "hermes_plugin",
        "trust": "authenticated_untrusted",
    }:
        raise APIError(
            HTTPStatus.BAD_REQUEST,
            "invalid_policy_attestation",
            "Policy attestation provenance is invalid",
        )
    payload = document.get("payload")
    required = {
        "profile",
        "plugin_version",
        "policy_version",
        "policy_digest",
        "guard_active",
        "policy_mode",
        "attested_at",
    }
    if not isinstance(payload, dict) or set(payload) != required:
        raise APIError(
            HTTPStatus.BAD_REQUEST,
            "invalid_policy_attestation",
            "Policy attestation payload does not match the fixed contract",
        )
    for key in required - {"guard_active"}:
        if not isinstance(payload.get(key), str) or not payload[key].strip():
            raise APIError(
                HTTPStatus.BAD_REQUEST,
                "invalid_policy_attestation",
                f"Policy attestation field {key} is invalid",
            )
    if payload.get("guard_active") is not True or payload.get("policy_mode") != "default_deny":
        raise APIError(
            HTTPStatus.BAD_REQUEST,
            "invalid_policy_attestation",
            "Policy attestation must report an active default-deny guard",
        )
    if not re.fullmatch(r"[0-9a-f]{64}", str(payload.get("policy_digest", ""))):
        raise APIError(
            HTTPStatus.BAD_REQUEST,
            "invalid_policy_attestation",
            "Policy attestation digest must be lowercase SHA-256 hex",
        )
    try:
        attested_at = datetime.fromisoformat(str(payload["attested_at"]))
    except ValueError as error:
        raise APIError(
            HTTPStatus.BAD_REQUEST,
            "invalid_policy_attestation",
            "Policy attestation timestamp is invalid",
        ) from error
    if (
        attested_at.tzinfo is None
        or attested_at.utcoffset() != timedelta(0)
        or attested_at.astimezone(UTC) > datetime.now(UTC) + timedelta(seconds=60)
        or document.get("occurred_at") != payload["attested_at"]
    ):
        raise APIError(
            HTTPStatus.BAD_REQUEST,
            "invalid_policy_attestation",
            "Policy attestation timestamp must be current UTC evidence",
        )
    identity = json.dumps(
        [
            payload["profile"],
            payload["plugin_version"],
            payload["policy_version"],
            payload["policy_digest"],
            payload["attested_at"],
        ],
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")
    expected_id = f"hermes-policy:{hashlib.sha256(identity).hexdigest()}"
    if (
        document.get("external_id") != expected_id
        or document.get("dedupe_key") != expected_id
    ):
        raise APIError(
            HTTPStatus.BAD_REQUEST,
            "invalid_policy_attestation",
            "Policy attestation identity digest is invalid",
        )
    return dict(payload)


def _handler_for(context: APIContext) -> type[BaseHTTPRequestHandler]:
    class OperatorAPIHandler(BaseHTTPRequestHandler):
        server_version = "HermesOperator/0.1"
        protocol_version = "HTTP/1.1"

        def do_GET(self) -> None:  # noqa: N802
            self._dispatch("GET")

        def do_POST(self) -> None:  # noqa: N802
            self._dispatch("POST")

        def do_PUT(self) -> None:  # noqa: N802
            self._method_not_allowed()

        def do_PATCH(self) -> None:  # noqa: N802
            self._method_not_allowed()

        def do_DELETE(self) -> None:  # noqa: N802
            self._method_not_allowed()

        def log_message(self, format: str, *args: Any) -> None:
            return

        def _dispatch(self, method: str) -> None:
            self._request_id = self.headers.get("X-Request-ID", "")[:128] or uuid.uuid4().hex
            try:
                split = urlsplit(self.path)
                path = split.path.rstrip("/") or "/"
                query = parse_qs(split.query, keep_blank_values=False)
                if method == "GET":
                    self._get(path, query)
                else:
                    self._post(path)
            except APIError as error:
                self._send_json(
                    error.status,
                    {"error": {"code": error.code, "message": error.message}},
                )
            except NotFound as error:
                self._send_json(
                    HTTPStatus.NOT_FOUND,
                    {"error": {"code": "not_found", "message": str(error.args[0])}},
                )
            except StateConflict as error:
                self._send_json(
                    HTTPStatus.CONFLICT,
                    {"error": {"code": "state_conflict", "message": str(error)}},
                )
            except ApprovalStateError as error:
                self._send_json(
                    HTTPStatus.CONFLICT,
                    {"error": {"code": "approval_state_conflict", "message": str(error)}},
                )
            except (InboundValidationError, ValueError) as error:
                self._send_json(
                    HTTPStatus.BAD_REQUEST,
                    {"error": {"code": "invalid_request", "message": str(error)}},
                )
            except Exception:
                self._send_json(
                    HTTPStatus.INTERNAL_SERVER_ERROR,
                    {
                        "error": {
                            "code": "internal_error",
                            "message": "The request could not be completed",
                        }
                    },
                )

        def _get(self, path: str, query: Mapping[str, list[str]]) -> None:
            if path == "/health":
                details: dict[str, Any] = {
                    "status": "ok",
                    "time": utc_now(),
                }
                if context.health_provider is not None:
                    # This endpoint is deliberately unauthenticated so load
                    # balancers can use it. Keep it to non-sensitive liveness
                    # fields; the authenticated status endpoint exposes the
                    # full operator snapshot.
                    supplied = dict(context.health_provider())
                    details["runtime"] = {
                        key: supplied[key]
                        for key in ("status", "running", "cycle_count")
                        if key in supplied
                    }
                self._send_json(HTTPStatus.OK, details)
                return

            if path == "/v1/status":
                self._require_operator(mutation=True)
                self._send_json(HTTPStatus.OK, context.store.snapshot())
                return
            if path == "/v1/work":
                self._require_operator(mutation=True)
                limit = self._query_limit(query, default=200, maximum=1000)
                statuses = _split_query_values(query.get("status", [])) or None
                kinds = _split_query_values(query.get("kind", [])) or None
                parent_values = query.get("parent_id", [])
                parent_id = parent_values[0] if parent_values else None
                items = context.store.list_work(
                    statuses=statuses,
                    kinds=kinds,
                    parent_id=parent_id,
                    limit=limit,
                )
                self._send_json(
                    HTTPStatus.OK,
                    {"items": [item.to_dict() for item in items], "count": len(items)},
                )
                return
            if path == "/v1/next":
                self._require_reader()
                limit = self._query_limit(query, default=5, maximum=100)
                items = self._next_items(limit)
                self._send_json(HTTPStatus.OK, {"items": items, "count": len(items)})
                return
            if path == "/v1/questions":
                reader_role = self._require_reader()
                limit = self._query_limit(query, default=100, maximum=1000)
                raw_status = query.get("status", [QuestionStatus.PENDING.value])[0]
                if (
                    reader_role == "bridge"
                    and raw_status != QuestionStatus.PENDING.value
                ):
                    raise APIError(
                        HTTPStatus.FORBIDDEN,
                        "bridge_question_scope",
                        "The Hermes bridge can read pending questions only",
                    )
                questions = context.store.list_questions(
                    status=raw_status,
                    limit=limit,
                )
                if reader_role == "bridge":
                    questions = [
                        {
                            key: value
                            for key, value in question.items()
                            if key not in {"answer", "answered_at"}
                        }
                        for question in questions
                    ]
                self._send_json(
                    HTTPStatus.OK,
                    {"items": questions, "count": len(questions)},
                )
                return
            if path == "/v1/hermes/execution-contract":
                self._require_bridge()
                values = query.get("task_id", [])
                if len(values) != 1 or not re.fullmatch(
                    r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", values[0]
                ):
                    raise APIError(
                        HTTPStatus.BAD_REQUEST,
                        "invalid_task_id",
                        "One valid Hermes task_id is required",
                    )
                if context.execution_contract_provider is None:
                    raise APIError(
                        HTTPStatus.SERVICE_UNAVAILABLE,
                        "execution_contract_unavailable",
                        "Task-scoped execution authorization is unavailable",
                    )
                contract = dict(context.execution_contract_provider(values[0]))
                if (
                    not isinstance(contract.get("authorized"), bool)
                    or contract.get("task_id") != values[0]
                ):
                    raise APIError(
                        HTTPStatus.SERVICE_UNAVAILABLE,
                        "execution_contract_invalid",
                        "Task-scoped execution authorization is invalid",
                    )
                self._send_json(HTTPStatus.OK, contract)
                return
            if path == "/v1/approvals":
                self._require_operator(mutation=True)
                if context.action_stager is None:
                    raise APIError(
                        HTTPStatus.SERVICE_UNAVAILABLE,
                        "approval_service_unavailable",
                        "Approval staging is not configured",
                    )
                limit = self._query_limit(query, default=100, maximum=1000)
                raw_status = query.get("status", ["pending_approval"])[0]
                actions = context.action_stager.list(status=raw_status, limit=limit)
                self._send_json(
                    HTTPStatus.OK,
                    {
                        "items": [action.to_dict(include_content=True) for action in actions],
                        "count": len(actions),
                    },
                )
                return
            if path == "/v1/memory":
                self._require_operator(mutation=True)
                limit = self._query_limit(query, default=200, maximum=1000)
                status_values = query.get("status", [])
                status = status_values[0] if status_values else None
                memories = context.store.list_memory(status=status, limit=limit)
                self._send_json(
                    HTTPStatus.OK,
                    {"items": memories, "count": len(memories)},
                )
                return
            memory_prefix = "/v1/memory/"
            if path.startswith(memory_prefix):
                self._require_operator(mutation=True)
                memory_id = unquote(path.removeprefix(memory_prefix)).strip("/")
                if not memory_id or "/" in memory_id:
                    raise APIError(HTTPStatus.NOT_FOUND, "not_found", "Endpoint not found")
                self._send_json(HTTPStatus.OK, context.store.get_memory(memory_id))
                return
            approval_prefix = "/v1/approvals/"
            if path.startswith(approval_prefix):
                self._require_operator(mutation=True)
                if context.action_stager is None:
                    raise APIError(
                        HTTPStatus.SERVICE_UNAVAILABLE,
                        "approval_service_unavailable",
                        "Approval staging is not configured",
                    )
                action_id = unquote(path.removeprefix(approval_prefix)).strip("/")
                if not action_id or "/" in action_id:
                    raise APIError(HTTPStatus.NOT_FOUND, "not_found", "Endpoint not found")
                action = context.action_stager.get(action_id)
                self._send_json(HTTPStatus.OK, action.to_dict(include_content=True))
                return
            raise APIError(HTTPStatus.NOT_FOUND, "not_found", "Endpoint not found")

        def _post(self, path: str) -> None:
            if path == "/v1/hermes/delegation-claim":
                self._require_bridge()
                if context.delegation_claim_provider is None:
                    raise APIError(
                        HTTPStatus.SERVICE_UNAVAILABLE,
                        "delegation_claim_unavailable",
                        "Task-scoped delegation authorization is unavailable",
                    )
                _, document = self._read_json()
                if set(document) != {"task_id", "requested_children"}:
                    raise APIError(
                        HTTPStatus.BAD_REQUEST,
                        "invalid_delegation_claim",
                        "Delegation claim must contain the exact task and child count",
                    )
                task_id = document.get("task_id")
                requested_children = document.get("requested_children")
                if not isinstance(task_id, str) or not re.fullmatch(
                    r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", task_id
                ):
                    raise APIError(
                        HTTPStatus.BAD_REQUEST,
                        "invalid_task_id",
                        "A valid Hermes task_id is required",
                    )
                if (
                    not isinstance(requested_children, int)
                    or isinstance(requested_children, bool)
                    or not 1 <= requested_children <= 3
                ):
                    raise APIError(
                        HTTPStatus.BAD_REQUEST,
                        "invalid_delegation_claim",
                        "requested_children must be an integer from 1 through 3",
                    )
                claim = dict(
                    context.delegation_claim_provider(
                        task_id,
                        requested_children,
                    )
                )
                if (
                    not isinstance(claim.get("claimed"), bool)
                    or claim.get("task_id") != task_id
                ):
                    raise APIError(
                        HTTPStatus.SERVICE_UNAVAILABLE,
                        "delegation_claim_invalid",
                        "Task-scoped delegation response is invalid",
                    )
                self._send_json(HTTPStatus.OK, claim)
                return
            if path.startswith("/v1/events/"):
                source = unquote(path.removeprefix("/v1/events/"))
                raw, document = self._read_json()
                configured = source in context.webhook_secrets
                authenticated = False
                bridge_authenticated = False
                if source == "hermes":
                    if not context.bridge_token:
                        raise APIError(
                            HTTPStatus.SERVICE_UNAVAILABLE,
                            "hermes_bridge_auth_unconfigured",
                            "Hermes bridge authentication is not configured",
                        )
                    if not hmac.compare_digest(
                        self.headers.get("Authorization", ""),
                        f"Bearer {context.bridge_token}",
                    ):
                        code = (
                            "policy_attestation_auth_required"
                            if document.get("event_type") == "policy.attested"
                            else "hermes_bridge_auth_required"
                        )
                        raise APIError(
                            HTTPStatus.UNAUTHORIZED,
                            code,
                            "The scoped Hermes bridge token is required",
                        )
                    authenticated = True
                    bridge_authenticated = True
                elif configured:
                    secret = context.webhook_secrets[source]
                    if not secret:
                        raise APIError(
                            HTTPStatus.SERVICE_UNAVAILABLE,
                            "webhook_secret_unavailable",
                            "The webhook source has no usable secret",
                        )
                    authenticated = verify_webhook_signature(
                        raw,
                        self.headers.get("X-Hermes-Signature"),
                        secret,
                    )
                    if not authenticated:
                        raise APIError(
                            HTTPStatus.UNAUTHORIZED,
                            "invalid_signature",
                            "Webhook signature is missing or invalid",
                        )
                elif context.api_token and hmac.compare_digest(
                    self.headers.get("Authorization", ""),
                    f"Bearer {context.api_token}",
                ):
                    authenticated = True
                elif not context.allow_unsigned_webhooks:
                    raise APIError(
                        HTTPStatus.UNAUTHORIZED,
                        "webhook_auth_required",
                        "A configured HMAC secret or operator bearer token is required",
                    )
                attestation = None
                if document.get("event_type") == "policy.attested":
                    if source != "hermes" or not bridge_authenticated:
                        raise APIError(
                            HTTPStatus.UNAUTHORIZED,
                            "policy_attestation_auth_required",
                            "Policy attestation requires the scoped Hermes bridge token",
                        )
                    attestation = _validated_policy_attestation(document)
                normalized = normalize_external_event(
                    source,
                    document,
                    authenticated=authenticated,
                    request_id=self._request_id,
                    remote_address=self.client_address[0] if self.client_address else None,
                )
                if attestation is not None:
                    attestation_id = str(document["external_id"])
                    created = context.store.record_policy_attestation(
                        str(attestation["profile"]),
                        attestation_id,
                        attestation,
                        actor="hermes-bridge",
                    )
                    self._send_json(
                        HTTPStatus.ACCEPTED if created else HTTPStatus.OK,
                        {
                            "event_id": attestation_id,
                            "created": created,
                            "trust_level": normalized.event.trust_level.value,
                        },
                    )
                    return
                event_id, created = context.store.enqueue_event(
                    normalized.event, actor="webhook"
                )
                event_type = str(document.get("event_type", ""))
                immediate_reconcile_types = {
                    "card.state_changed",
                    "execution.state_changed",
                    "task.state_changed",
                }
                wake_reason = (
                    "hermes-state"
                    if source == "hermes" and event_type in immediate_reconcile_types
                    else f"event:{source}"
                )
                if created:
                    self._wake(wake_reason)
                self._send_json(
                    HTTPStatus.ACCEPTED if created else HTTPStatus.OK,
                    {"event_id": event_id, "created": created, "trust_level": normalized.event.trust_level.value},
                )
                return

            if path == "/v1/ingest":
                self._require_operator(mutation=True)
                _, document = self._read_json()
                normalized = normalize_operator_event(
                    document,
                    request_id=self._request_id,
                )
                event_id, created = context.store.enqueue_event(normalized.event, actor="operator-api")
                if created:
                    self._wake("operator-ingest")
                self._send_json(
                    HTTPStatus.ACCEPTED if created else HTTPStatus.OK,
                    {"event_id": event_id, "created": created, "trust_level": normalized.event.trust_level.value},
                )
                return

            if path == "/v1/wake":
                self._require_operator(mutation=True)
                _, document = self._read_json(allow_empty=True)
                reason = document.get("reason", "operator")
                if not isinstance(reason, str) or not reason.strip() or len(reason) > 128:
                    raise APIError(
                        HTTPStatus.BAD_REQUEST,
                        "invalid_reason",
                        "reason must be a nonempty string of at most 128 characters",
                    )
                self._wake(reason.strip())
                self._send_json(HTTPStatus.ACCEPTED, {"woken": True, "reason": reason.strip()})
                return

            if path == "/v1/work/links":
                self._require_operator(mutation=True)
                _, document = self._read_json()
                required = {
                    "from_id",
                    "to_id",
                    "relation",
                    "expected_from_version",
                    "expected_to_version",
                }
                if set(document) != required:
                    raise APIError(
                        HTTPStatus.BAD_REQUEST,
                        "invalid_work_link",
                        "Work link payload must contain the exact link contract",
                    )
                from_id = str(document["from_id"]).strip()
                to_id = str(document["to_id"]).strip()
                if not from_id or not to_id:
                    raise ValueError("Work link endpoint IDs cannot be empty")
                from_version = int(document["expected_from_version"])
                to_version = int(document["expected_to_version"])
                if from_version < 1 or to_version < 1:
                    raise ValueError("Work link versions must be positive integers")
                relation = WorkRelation(str(document["relation"]))
                link_id = context.store.add_work_link(
                    from_id,
                    to_id,
                    relation,
                    actor="operator-api",
                    expected_from_version=from_version,
                    expected_to_version=to_version,
                )
                self._wake("work-linked")
                self._send_json(
                    HTTPStatus.CREATED,
                    {
                        "id": link_id,
                        "from_id": from_id,
                        "to_id": to_id,
                        "relation": relation.value,
                    },
                )
                return

            run_prefix = "/v1/runs/"
            run_suffix = "/resolve"
            if path.startswith(run_prefix) and path.endswith(run_suffix):
                self._require_operator(mutation=True)
                run_id = unquote(
                    path[len(run_prefix) : -len(run_suffix)]
                ).strip("/")
                if not run_id or "/" in run_id:
                    raise APIError(
                        HTTPStatus.NOT_FOUND,
                        "not_found",
                        "Endpoint not found",
                    )
                _, document = self._read_json()
                if set(document) != {"expected_status", "reason"}:
                    raise APIError(
                        HTTPStatus.BAD_REQUEST,
                        "invalid_run_resolution",
                        "Run resolution requires expected_status and reason",
                    )
                result = context.store.resolve_run(
                    run_id,
                    expected_status=str(document["expected_status"]),
                    reason=str(document["reason"]),
                    actor="operator-api",
                )
                self._wake("run-resolved")
                self._send_json(HTTPStatus.OK, result)
                return

            prefix = "/v1/questions/"
            suffix = "/answer"
            if path.startswith(prefix) and path.endswith(suffix):
                self._require_operator(mutation=True)
                question_id = unquote(path[len(prefix) : -len(suffix)]).strip("/")
                if not question_id or "/" in question_id:
                    raise APIError(HTTPStatus.NOT_FOUND, "not_found", "Endpoint not found")
                _, document = self._read_json()
                answer = document.get("answer")
                if not isinstance(answer, str):
                    raise APIError(
                        HTTPStatus.BAD_REQUEST,
                        "invalid_answer",
                        "answer must be a string",
                    )
                result = context.store.answer_question(question_id, answer, actor="operator-api")
                self._wake("question-answered")
                self._send_json(HTTPStatus.OK, result)
                return

            approval_prefix = "/v1/approvals/"
            for decision in ("approve", "deny"):
                decision_suffix = f"/{decision}"
                if path.startswith(approval_prefix) and path.endswith(decision_suffix):
                    self._require_operator(mutation=True)
                    if context.action_stager is None:
                        raise APIError(
                            HTTPStatus.SERVICE_UNAVAILABLE,
                            "approval_service_unavailable",
                            "Approval staging is not configured",
                        )
                    action_id = unquote(
                        path[len(approval_prefix) : -len(decision_suffix)]
                    ).strip("/")
                    if not action_id or "/" in action_id:
                        raise APIError(
                            HTTPStatus.NOT_FOUND, "not_found", "Endpoint not found"
                        )
                    _, document = self._read_json(allow_empty=True)
                    if decision == "approve":
                        grant = context.action_stager.approve(
                            action_id, approved_by="operator-api"
                        )
                        self._wake("external-action-approved")
                        self._send_json(
                            HTTPStatus.OK,
                            {
                                "action_id": action_id,
                                "status": "approved",
                                "grant_id": grant.grant_id,
                                "expires_at": grant.expires_at.isoformat(),
                            },
                        )
                    else:
                        reason = document.get("reason", "")
                        if not isinstance(reason, str) or len(reason) > 2000:
                            raise APIError(
                                HTTPStatus.BAD_REQUEST,
                                "invalid_reason",
                                "reason must be a string of at most 2000 characters",
                            )
                        context.action_stager.deny(
                            action_id, denied_by="operator-api", reason=reason
                        )
                        self._wake("external-action-denied")
                        self._send_json(
                            HTTPStatus.OK,
                            {"action_id": action_id, "status": "denied"},
                        )
                    return

            memory_prefix = "/v1/memory/"
            for decision, stored_decision in (
                ("promote", "promoted"),
                ("reject", "rejected"),
            ):
                decision_suffix = f"/{decision}"
                if path.startswith(memory_prefix) and path.endswith(decision_suffix):
                    self._require_operator(mutation=True)
                    memory_id = unquote(
                        path[len(memory_prefix) : -len(decision_suffix)]
                    ).strip("/")
                    if not memory_id or "/" in memory_id:
                        raise APIError(
                            HTTPStatus.NOT_FOUND, "not_found", "Endpoint not found"
                        )
                    self._read_json(allow_empty=True)
                    result = context.store.review_memory(
                        memory_id,
                        decision=stored_decision,
                        actor="operator-api",
                    )
                    self._wake(f"memory-{decision}")
                    self._send_json(HTTPStatus.OK, result)
                    return

            raise APIError(HTTPStatus.NOT_FOUND, "not_found", "Endpoint not found")

        def _read_json(self, *, allow_empty: bool = False) -> tuple[bytes, dict[str, Any]]:
            content_type = self.headers.get("Content-Type", "")
            if not content_type.lower().startswith("application/json"):
                raise APIError(
                    HTTPStatus.UNSUPPORTED_MEDIA_TYPE,
                    "unsupported_media_type",
                    "Content-Type must be application/json",
                )
            raw_length = self.headers.get("Content-Length")
            if raw_length is None:
                raise APIError(
                    HTTPStatus.LENGTH_REQUIRED,
                    "length_required",
                    "Content-Length is required",
                )
            try:
                length = int(raw_length)
            except ValueError as error:
                raise APIError(
                    HTTPStatus.BAD_REQUEST,
                    "invalid_content_length",
                    "Content-Length is invalid",
                ) from error
            if length < 0:
                raise APIError(
                    HTTPStatus.BAD_REQUEST,
                    "invalid_content_length",
                    "Content-Length is invalid",
                )
            if length > context.max_body_bytes:
                self.close_connection = True
                raise APIError(
                    HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
                    "body_too_large",
                    f"Request body exceeds {context.max_body_bytes} bytes",
                )
            raw = self.rfile.read(length)
            if not raw and allow_empty:
                return raw, {}
            try:
                document = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as error:
                raise APIError(
                    HTTPStatus.BAD_REQUEST,
                    "invalid_json",
                    "Request body must contain valid UTF-8 JSON",
                ) from error
            if not isinstance(document, dict):
                raise APIError(
                    HTTPStatus.BAD_REQUEST,
                    "invalid_json_type",
                    "JSON body must be an object",
                )
            return raw, document

        def _require_operator(self, *, mutation: bool) -> None:
            token = context.api_token
            if not token:
                if mutation:
                    raise APIError(
                        HTTPStatus.SERVICE_UNAVAILABLE,
                        "operator_auth_unconfigured",
                        "Operator API authentication is not configured",
                    )
                return
            authorization = self.headers.get("Authorization", "")
            expected = f"Bearer {token}"
            if not hmac.compare_digest(authorization, expected):
                raise APIError(
                    HTTPStatus.UNAUTHORIZED,
                    "unauthorized",
                    "A valid operator bearer token is required",
                )

        def _require_reader(self) -> str:
            if not context.api_token and not context.bridge_token:
                return "operator"
            authorization = self.headers.get("Authorization", "")
            if context.api_token and hmac.compare_digest(
                authorization,
                f"Bearer {context.api_token}",
            ):
                return "operator"
            if context.bridge_token and hmac.compare_digest(
                authorization,
                f"Bearer {context.bridge_token}",
            ):
                return "bridge"
            raise APIError(
                HTTPStatus.UNAUTHORIZED,
                "unauthorized",
                "A valid reader bearer token is required",
            )

        def _require_bridge(self) -> None:
            if not context.bridge_token:
                raise APIError(
                    HTTPStatus.SERVICE_UNAVAILABLE,
                    "hermes_bridge_auth_unconfigured",
                    "Hermes bridge authentication is not configured",
                )
            authorization = self.headers.get("Authorization", "")
            if not hmac.compare_digest(
                authorization,
                f"Bearer {context.bridge_token}",
            ):
                raise APIError(
                    HTTPStatus.UNAUTHORIZED,
                    "unauthorized",
                    "The scoped Hermes bridge token is required",
                )

        def _wake(self, reason: str) -> None:
            if context.wake is not None:
                context.wake(reason)

        def _next_items(self, limit: int) -> list[dict[str, Any]]:
            if context.next_provider is not None:
                supplied = context.next_provider(limit)
                return [_work_to_dict(item) for item in supplied][:limit]
            candidates = context.store.list_work(
                statuses=[WorkStatus.TRIAGE, WorkStatus.READY, WorkStatus.REVIEW],
                dependencies_satisfied_only=True,
                limit=max(limit * 4, limit),
            )
            return [item.to_dict() for item in candidates[:limit]]

        @staticmethod
        def _query_limit(
            query: Mapping[str, list[str]], *, default: int, maximum: int
        ) -> int:
            raw = query.get("limit", [str(default)])[0]
            try:
                value = int(raw)
            except ValueError as error:
                raise APIError(
                    HTTPStatus.BAD_REQUEST,
                    "invalid_limit",
                    "limit must be an integer",
                ) from error
            if not 1 <= value <= maximum:
                raise APIError(
                    HTTPStatus.BAD_REQUEST,
                    "invalid_limit",
                    f"limit must be between 1 and {maximum}",
                )
            return value

        def _method_not_allowed(self) -> None:
            self._request_id = self.headers.get("X-Request-ID", "")[:128] or uuid.uuid4().hex
            self._send_json(
                HTTPStatus.METHOD_NOT_ALLOWED,
                {"error": {"code": "method_not_allowed", "message": "Method not allowed"}},
            )

        def _send_json(self, status: HTTPStatus, document: Mapping[str, Any]) -> None:
            payload = json.dumps(
                document,
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
            ).encode("utf-8")
            self.send_response(int(status))
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Request-ID", self._request_id)
            self.end_headers()
            self.wfile.write(payload)

    return OperatorAPIHandler


def _split_query_values(values: Sequence[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        result.extend(part.strip() for part in value.split(",") if part.strip())
    return result


def _work_to_dict(item: WorkItem | Mapping[str, Any]) -> dict[str, Any]:
    if isinstance(item, WorkItem):
        return item.to_dict()
    return dict(item)
