from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any


def utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


class TrustLevel(StrEnum):
    UNTRUSTED = "untrusted"
    AUTHENTICATED_UNTRUSTED = "authenticated_untrusted"
    OPERATOR = "operator"
    SYSTEM = "system"


class EventState(StrEnum):
    PENDING = "pending"
    PROCESSING = "processing"
    PROCESSED = "processed"
    FAILED = "failed"
    DEAD_LETTER = "dead_letter"


class WorkKind(StrEnum):
    AREA = "area"
    GOAL = "goal"
    PROJECT = "project"
    MILESTONE = "milestone"
    TASK = "task"
    TODO = "todo"
    REMINDER = "reminder"
    DECISION = "decision"


class WorkStatus(StrEnum):
    INBOX = "inbox"
    TRIAGE = "triage"
    PLANNED = "planned"
    READY = "ready"
    RUNNING = "running"
    WAITING_INPUT = "waiting_input"
    BLOCKED = "blocked"
    REVIEW = "review"
    DONE = "done"
    CANCELLED = "cancelled"
    ARCHIVED = "archived"


class ExecutionMode(StrEnum):
    NONE = "none"
    HERMES = "hermes"


TERMINAL_WORK_STATUSES = {
    WorkStatus.DONE,
    WorkStatus.CANCELLED,
    WorkStatus.ARCHIVED,
}


ALLOWED_WORK_TRANSITIONS: dict[WorkStatus, set[WorkStatus]] = {
    WorkStatus.INBOX: {WorkStatus.TRIAGE, WorkStatus.PLANNED, WorkStatus.READY, WorkStatus.CANCELLED},
    WorkStatus.TRIAGE: {WorkStatus.PLANNED, WorkStatus.READY, WorkStatus.WAITING_INPUT, WorkStatus.CANCELLED},
    WorkStatus.PLANNED: {WorkStatus.READY, WorkStatus.BLOCKED, WorkStatus.WAITING_INPUT, WorkStatus.CANCELLED},
    WorkStatus.READY: {WorkStatus.RUNNING, WorkStatus.BLOCKED, WorkStatus.WAITING_INPUT, WorkStatus.CANCELLED},
    WorkStatus.RUNNING: {WorkStatus.REVIEW, WorkStatus.DONE, WorkStatus.BLOCKED, WorkStatus.WAITING_INPUT, WorkStatus.READY, WorkStatus.CANCELLED},
    WorkStatus.WAITING_INPUT: {WorkStatus.TRIAGE, WorkStatus.PLANNED, WorkStatus.READY, WorkStatus.BLOCKED, WorkStatus.CANCELLED},
    WorkStatus.BLOCKED: {WorkStatus.PLANNED, WorkStatus.READY, WorkStatus.WAITING_INPUT, WorkStatus.CANCELLED},
    WorkStatus.REVIEW: {WorkStatus.DONE, WorkStatus.READY, WorkStatus.BLOCKED, WorkStatus.WAITING_INPUT, WorkStatus.CANCELLED},
    WorkStatus.DONE: {WorkStatus.ARCHIVED, WorkStatus.READY},
    WorkStatus.CANCELLED: {WorkStatus.ARCHIVED, WorkStatus.TRIAGE},
    WorkStatus.ARCHIVED: {WorkStatus.TRIAGE},
}


class WorkRelation(StrEnum):
    DEPENDS_ON = "depends_on"
    BLOCKS = "blocks"
    RELATED_TO = "related_to"
    DUPLICATES = "duplicates"
    DERIVED_FROM = "derived_from"


class QuestionStatus(StrEnum):
    PENDING = "pending"
    ANSWERED = "answered"
    DISMISSED = "dismissed"


@dataclass(slots=True)
class Provenance:
    source: str
    external_id: str | None = None
    trust_level: TrustLevel = TrustLevel.UNTRUSTED
    received_at: str = field(default_factory=utc_now)
    actor: str | None = None
    content_digest: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["trust_level"] = self.trust_level.value
        return result


@dataclass(slots=True)
class Event:
    source: str
    event_type: str
    payload: dict[str, Any]
    trust_level: TrustLevel = TrustLevel.UNTRUSTED
    external_id: str | None = None
    dedupe_key: str | None = None
    provenance: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: new_id("evt"))
    state: EventState = EventState.PENDING
    created_at: str = field(default_factory=utc_now)
    available_at: str = field(default_factory=utc_now)
    attempt_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["trust_level"] = self.trust_level.value
        result["state"] = self.state.value
        return result


@dataclass(slots=True)
class WorkItem:
    title: str
    kind: WorkKind = WorkKind.TASK
    description: str = ""
    status: WorkStatus = WorkStatus.TRIAGE
    parent_id: str | None = None
    source_event_id: str | None = None
    provenance: dict[str, Any] = field(default_factory=dict)
    priority: int = 0
    priority_score: float = 0.0
    priority_rationale: str = ""
    impact: float = 0.5
    urgency: float = 0.5
    strategic_alignment: float = 0.5
    unlock_value: float = 0.0
    risk: float = 0.0
    confidence: float = 0.5
    effort_minutes: int = 30
    due_at: str | None = None
    scheduled_at: str | None = None
    assignee: str | None = None
    execution_mode: ExecutionMode = ExecutionMode.NONE
    hermes_task_id: str | None = None
    acceptance_criteria: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: new_id("wrk"))
    version: int = 1
    created_at: str = field(default_factory=utc_now)
    updated_at: str = field(default_factory=utc_now)
    completed_at: str | None = None

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["kind"] = self.kind.value
        result["status"] = self.status.value
        result["execution_mode"] = self.execution_mode.value
        return result

    @classmethod
    def from_row(cls, row: Any) -> "WorkItem":
        return cls(
            id=row["id"],
            title=row["title"],
            kind=WorkKind(row["kind"]),
            description=row["description"],
            status=WorkStatus(row["status"]),
            parent_id=row["parent_id"],
            source_event_id=row["source_event_id"],
            provenance=json.loads(row["provenance_json"] or "{}"),
            priority=row["priority"],
            priority_score=row["priority_score"],
            priority_rationale=row["priority_rationale"],
            impact=row["impact"],
            urgency=row["urgency"],
            strategic_alignment=row["strategic_alignment"],
            unlock_value=row["unlock_value"],
            risk=row["risk"],
            confidence=row["confidence"],
            effort_minutes=row["effort_minutes"],
            due_at=row["due_at"],
            scheduled_at=row["scheduled_at"],
            assignee=row["assignee"],
            execution_mode=ExecutionMode(row["execution_mode"]),
            hermes_task_id=row["hermes_task_id"],
            acceptance_criteria=json.loads(row["acceptance_criteria_json"] or "[]"),
            metadata=json.loads(row["metadata_json"] or "{}"),
            version=row["version"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            completed_at=row["completed_at"],
        )


@dataclass(slots=True)
class UserQuestion:
    question: str
    context: str = ""
    urgency: float = 0.5
    blocking_work_ids: list[str] = field(default_factory=list)
    id: str = field(default_factory=lambda: new_id("qst"))
    status: QuestionStatus = QuestionStatus.PENDING
    answer: str | None = None
    created_at: str = field(default_factory=utc_now)
    answered_at: str | None = None


@dataclass(slots=True)
class RunRecord:
    work_item_id: str
    runner: str
    status: str = "queued"
    external_run_id: str | None = None
    attempt: int = 1
    result: dict[str, Any] = field(default_factory=dict)
    error: str | None = None
    id: str = field(default_factory=lambda: new_id("run"))
    started_at: str | None = None
    heartbeat_at: str | None = None
    finished_at: str | None = None
